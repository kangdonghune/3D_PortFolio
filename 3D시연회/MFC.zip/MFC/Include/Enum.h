#pragma once


namespace Charictor
{
	enum TYPE { HUNTER, Gobline };
}

namespace TerrainTool
{
	enum TYPE { SPHERE, CELL, TERRAIN_END};
}