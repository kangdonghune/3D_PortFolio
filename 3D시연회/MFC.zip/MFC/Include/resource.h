//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// MFC.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCTYPE                     130
#define IDD_FORM                        310
#define IDD_Object                      324
#define IDD_Char                        325
#define IDD_Terrain                     326
#define IDC_MFCSHELLTREE1               1005
#define IDC_TAB1                        1009
#define IDC_CHECK1                      1011
#define IDC_COMBO1                      1014
#define IDC_EDIT1                       1024
#define IDC_EDIT2                       1025
#define IDC_EDIT3                       1026
#define IDC_EDIT4                       1027
#define IDC_EDIT9                       1028
#define IDC_EDIT10                      1029
#define IDC_SLIDER2                     1033
#define IDC_SLIDER3                     1034
#define IDC_SLIDER4                     1035
#define IDC_TREE1                       1036
#define IDC_TREE2                       1040
#define IDC_SPIN1                       1044
#define IDC_SPIN2                       1045
#define IDC_SPIN3                       1046
#define IDC_EDIT5                       1052
#define IDC_EDIT6                       1053
#define IDC_SPIN5                       1054
#define IDC_SLIDER5                     1055
#define IDC_SPIN6                       1056
#define IDC_SLIDER6                     1057
#define IDC_EDIT7                       1058
#define IDC_SPIN7                       1059
#define IDC_SLIDER7                     1060
#define IDC_BUTTON1                     1061
#define IDC_BUTTON2                     1062
#define IDC_BUTTON3                     1063
#define IDC_EDIT8                       1064
#define IDC_BUTTON7                     1064
#define IDC_SPIN8                       1065
#define IDC_SLIDER8                     1066
#define IDC_BUTTON5                     1067
#define IDC_BUTTON4                     1068
#define IDC_BUTTON6                     1068
#define IDC_RADIO1                      1068
#define IDC_RADIO2                      1069
#define IDC_BUTTON9                     1071
#define IDC_RADIO3                      1072
#define IDC_BUTTON10                    1073
#define IDC_BUTTON11                    1074

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        330
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1075
#define _APS_NEXT_SYMED_VALUE           311
#endif
#endif
