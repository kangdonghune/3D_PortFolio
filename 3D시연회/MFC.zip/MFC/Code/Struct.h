#pragma once
#include "Export_Function.h"

typedef struct TagMFCCell
{
	CCell* pCell;
	_int PointA;
	_int PointB;
	_int PointC;
}MFCCELL;