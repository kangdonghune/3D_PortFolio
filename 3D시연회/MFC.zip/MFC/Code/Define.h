#ifndef Define_h__
#define Define_h__

#define	WINCX		800
#define WINCY		600

#define FORMCX		600
#define FORMCY		600

extern HWND		 g_HWnd;
extern HWND		 g_MainViewHwnd;
extern HINSTANCE g_HInst;


#endif // Define_h__